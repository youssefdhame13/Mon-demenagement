# Mon Déménagement — V8

Version Android native préparée pour le prochain test réel.

## Parcours
- Choix de la pièce
- Jusqu'à 8 photos par pièce
- Appareil photo ou galerie
- Envoi multipart vers le backend `/v1/analyze-room`
- Affichage du volume et de la confiance retournés
- Mode test automatique si le serveur est indisponible
- Test de connexion `/health`

## Backend
L'adresse est dans `app/src/main/res/values/strings.xml` (`backend_url`).
Pour un téléphone réel, utiliser une URL HTTPS accessible depuis Internet ou le réseau local. `10.0.2.2` correspond à l'émulateur Android.

## Important
Le backend V6/V7 fourni précédemment utilise encore une analyse de démonstration. Cette V8 prépare le vrai échange photo -> serveur, mais le moteur de vision doit encore être remplacé par un modèle de vision calibré sur des données réelles de déménagement.
