package com.mondemenagement.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private var pendingCameraFile: File? = null
    private val roomPhotos = mutableListOf<Uri>()
    private var selectedRoom = "Salon"
    private val roomVolumes = mutableListOf<Pair<String, Double>>()

    private lateinit var status: TextView
    private lateinit var photoCount: TextView
    private lateinit var result: TextView
    private lateinit var progress: ProgressBar
    private lateinit var roomSpinner: Spinner

    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok && pendingCameraFile != null) {
            roomPhotos.add(Uri.fromFile(pendingCameraFile!!))
            refreshPhotoCount()
        }
    }

    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris != null) {
            roomPhotos.addAll(uris.take(8 - roomPhotos.size))
            refreshPhotoCount()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        photoCount = findViewById(R.id.photoCount)
        result = findViewById(R.id.result)
        progress = findViewById(R.id.progress)
        roomSpinner = findViewById(R.id.roomSpinner)

        roomSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Salon", "Cuisine", "Chambre 1", "Chambre 2", "Salle de bain", "Bureau", "Garage", "Cave", "Autre"))
        roomSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedRoom = parent?.getItemAtPosition(position).toString()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        findViewById<Button>(R.id.btnCamera).setOnClickListener { takePhoto() }
        findViewById<Button>(R.id.btnGallery).setOnClickListener { galleryLauncher.launch("image/*") }
        findViewById<Button>(R.id.btnAnalyze).setOnClickListener { analyzeRoom() }
        findViewById<Button>(R.id.btnReset).setOnClickListener { resetRoom() }
        findViewById<Button>(R.id.btnTest).setOnClickListener { testServer() }

        refreshPhotoCount()
    }

    private fun takePhoto() {
        if (roomPhotos.size >= 8) {
            status.text = "Maximum de 8 photos par pièce."
            return
        }
        try {
            val dir = File(cacheDir, "rooms").apply { mkdirs() }
            pendingCameraFile = File(dir, "${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(this, "${BuildConfig.APPLICATION_ID}.fileprovider", pendingCameraFile!!)
            cameraLauncher.launch(uri)
        } catch (e: Exception) {
            status.text = "Impossible d'ouvrir l'appareil photo : ${e.message}"
        }
    }

    private fun refreshPhotoCount() {
        photoCount.text = "${roomPhotos.size}/8 photo(s) pour $selectedRoom"
    }

    private fun analyzeRoom() {
        if (roomPhotos.isEmpty()) {
            status.text = "Ajoute au moins une photo de la pièce."
            return
        }
        setBusy(true, "Analyse de $selectedRoom…")
        executor.execute {
            val response = try { uploadRoom(selectedRoom, roomPhotos) } catch (e: Exception) { null }
            runOnUiThread {
                setBusy(false, "")
                if (response != null) {
                    val volume = response.optDouble("volume_m3", 0.0)
                    val confidence = response.optDouble("confidence", 0.0)
                    roomVolumes.removeAll { it.first == selectedRoom }
                    roomVolumes.add(selectedRoom to volume)
                    result.text = "${selectedRoom} : ${"%.1f".format(volume)} m³\nConfiance indicative : ${"%.0f".format(confidence * 100)} %"
                    status.text = "Pièce analysée ✓"
                } else {
                    val fallback = demoVolume(selectedRoom)
                    roomVolumes.removeAll { it.first == selectedRoom }
                    roomVolumes.add(selectedRoom to fallback)
                    result.text = "${selectedRoom} : ${"%.1f".format(fallback)} m³\nMode test : estimation locale"
                    status.text = "Serveur indisponible : mode test utilisé."
                }
                roomPhotos.clear()
                refreshPhotoCount()
            }
        }
    }

    private fun uploadRoom(room: String, photos: List<Uri>): JSONObject {
        val base = getString(R.string.backend_url).trimEnd('/')
        val boundary = "----MonDemenagement${System.currentTimeMillis()}"
        val url = URL("$base/v1/analyze-room")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 10000
            readTimeout = 30000
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        }
        conn.outputStream.use { out ->
            fun writeText(name: String, value: String) {
                out.write(("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n").toByteArray())
            }
            writeText("room_name", room)
            photos.forEachIndexed { index, uri ->
                val bytes = readUri(uri)
                out.write(("--$boundary\r\nContent-Disposition: form-data; name=\"photos\"; filename=\"room_$index.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n").toByteArray())
                out.write(bytes)
                out.write("\r\n".toByteArray())
            }
            out.write("--$boundary--\r\n".toByteArray())
        }
        if (conn.responseCode !in 200..299) throw IOException("HTTP ${conn.responseCode}")
        return JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
    }

    private fun readUri(uri: Uri): ByteArray {
        if (uri.scheme == "file") {
            return File(uri.path ?: throw IOException("Photo illisible")).readBytes()
        }
        return contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IOException("Photo illisible")
    }

    private fun demoVolume(room: String): Double = when (room) {
        "Salon" -> 12.0
        "Cuisine" -> 6.0
        "Chambre 1", "Chambre 2" -> 7.0
        "Garage" -> 10.0
        "Cave" -> 5.0
        else -> 4.0
    }

    private fun testServer() {
        setBusy(true, "Test du serveur…")
        executor.execute {
            val ok = try {
                val c = URL("${getString(R.string.backend_url).trimEnd('/')}/health").openConnection() as HttpURLConnection
                c.connectTimeout = 4000
                c.readTimeout = 4000
                c.responseCode in 200..299
            } catch (_: Exception) { false }
            runOnUiThread {
                setBusy(false, if (ok) "Serveur connecté ✓" else "Serveur inaccessible")
            }
        }
    }

    private fun resetRoom() {
        roomPhotos.clear()
        result.text = ""
        status.text = "Prêt"
        refreshPhotoCount()
    }

    private fun setBusy(busy: Boolean, message: String) {
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        status.text = message
        findViewById<Button>(R.id.btnCamera).isEnabled = !busy
        findViewById<Button>(R.id.btnGallery).isEnabled = !busy
        findViewById<Button>(R.id.btnAnalyze).isEnabled = !busy
        findViewById<Button>(R.id.btnTest).isEnabled = !busy
    }
}
