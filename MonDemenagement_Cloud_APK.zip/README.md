# Mon Déménagement — projet Android Studio

Ouvre ce dossier dans Android Studio.

Pour créer l'APK : **Build > Build APK(s)**.

Le bouton « Tester le serveur » utilise `10.0.2.2:8000` pour l'émulateur Android. Pour un téléphone réel, remplace cette adresse par l'adresse IP ou le domaine du serveur.

Cette version est le socle Android natif. Le prochain développement est l'écran de prise de photos, l'envoi multipart des photos et l'intégration du vrai moteur de vision.
