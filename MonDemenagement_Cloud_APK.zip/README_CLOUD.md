
# Mon Déménagement — compilation APK sans ordinateur

Le workflow GitHub `build-apk.yml` compile automatiquement l'application.

## Depuis un téléphone
1. Créer un compte GitHub.
2. Créer un nouveau dépôt, par exemple `mon-demenagement`.
3. Extraire ce ZIP avec l'application **Mes fichiers**.
4. Dans GitHub, ouvrir le dépôt puis **Add file → Upload files**.
5. Envoyer tous les fichiers du dossier du projet.
6. Aller dans **Actions**.
7. Ouvrir **Construire APK Mon Déménagement**.
8. Appuyer sur **Run workflow** si nécessaire.
9. Quand la compilation est terminée, ouvrir l'exécution.
10. Dans **Artifacts**, télécharger `MonDemenagement-debug`.
11. Extraire l'archive téléchargée : elle contient `app-debug.apk`.
12. Ouvrir l'APK sur le téléphone et autoriser l'installation depuis cette source si Android le demande.

Le fichier APK est une version de test (debug), pas encore une version Play Store.
