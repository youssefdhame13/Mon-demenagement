package com.mondemenagement.app

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val status = findViewById<TextView>(R.id.status)
        findViewById<Button>(R.id.btnStart).setOnClickListener {
            status.text = "Prochaine étape : choisir les pièces puis prendre les photos."
        }
        findViewById<Button>(R.id.btnTest).setOnClickListener {
            status.text = "Le serveur doit être lancé pour effectuer le test."
            Thread {
                try {
                    val c = URL("http://10.0.2.2:8000/health").openConnection() as HttpURLConnection
                    c.connectTimeout = 3000
                    c.readTimeout = 3000
                    val ok = c.responseCode in 200..299
                    runOnUiThread { status.text = if (ok) "Serveur connecté ✓" else "Serveur inaccessible" }
                } catch (e: Exception) {
                    runOnUiThread { status.text = "Serveur inaccessible — configure l'adresse du serveur." }
                }
            }.start()
        }
    }
}
