# MonDéménagement

Application de préparation de déménagement.

## Contenu

- `android-app/` : application Android native Kotlin.
- `backend/` : API FastAPI pour l'analyse des pièces et le calcul du volume.
- `docs/` : architecture et contrat API.

## Fonctionnement prévu

1. Le client renseigne l'adresse de départ et d'arrivée.
2. Il indique les pièces.
3. Il prend ou sélectionne des photos.
4. Le serveur analyse les photos et estime le volume en m³.
5. L'application recommande une taille de camion.
6. Elle estime le nombre de cartons.
7. Le client peut ensuite demander des devis à des déménageurs.

> Important : une estimation à partir de photos reste une estimation. Pour une mesure exacte, une vérification humaine ou une mesure physique est nécessaire.

## Démarrer l'API

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```

API locale : `http://127.0.0.1:8000`

Documentation automatique : `http://127.0.0.1:8000/docs`

## Android

Ouvre le dossier `android-app/` avec Android Studio.

L'application fonctionne en mode démonstration sans serveur. Le point d'accès du backend est configurable dans `MainActivity.kt`.

Pour un téléphone physique, ne mets pas `127.0.0.1` pour joindre un serveur installé sur ton PC : utilise l'adresse IP locale du PC ou une URL HTTPS de production.

## Sécurité

- Ne mets jamais une clé API dans l'application Android.
- Les clés de fournisseurs IA doivent rester côté backend.
- En production, utilise HTTPS, authentification, limitation de taille des fichiers et politique de conservation des photos.
