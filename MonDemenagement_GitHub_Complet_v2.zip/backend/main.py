from typing import List
from fastapi import FastAPI, File, Form, UploadFile, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="MonDéménagement API", version="1.0.0")

MAX_FILE_SIZE = 10 * 1024 * 1024
ALLOWED_TYPES = {"image/jpeg", "image/png", "image/webp"}


class DetectedItem(BaseModel):
    name: str
    quantity: int = Field(ge=1)
    estimated_volume_m3: float = Field(ge=0)
    confidence: float = Field(ge=0, le=1)


class RoomAnalysis(BaseModel):
    room_name: str
    volume_m3: float
    confidence: float
    items: List[DetectedItem]
    needs_more_photos: bool = False


class RoomInput(BaseModel):
    name: str
    volume_m3: float = Field(ge=0)


class MoveRequest(BaseModel):
    rooms: List[RoomInput]


def demo_analysis(room_name: str) -> RoomAnalysis:
    # Démo : ces valeurs ne correspondent pas à une vraie analyse d'image.
    items = [
        DetectedItem(name="Canapé", quantity=1, estimated_volume_m3=1.20, confidence=0.94),
        DetectedItem(name="Table", quantity=1, estimated_volume_m3=0.55, confidence=0.89),
        DetectedItem(name="Chaise", quantity=4, estimated_volume_m3=0.18, confidence=0.91),
    ]
    volume = round(sum(x.estimated_volume_m3 * x.quantity for x in items), 2)
    return RoomAnalysis(
        room_name=room_name,
        volume_m3=volume,
        confidence=0.91,
        items=items,
    )


@app.get("/health")
def health():
    return {"status": "ok", "service": "mon-demenagement-api"}


@app.post("/v1/analyze-room", response_model=RoomAnalysis)
async def analyze_room(
    room_name: str = Form(...),
    photos: List[UploadFile] = File(...),
):
    if not 1 <= len(photos) <= 8:
        raise HTTPException(status_code=400, detail="Il faut entre 1 et 8 photos.")

    for photo in photos:
        if photo.content_type not in ALLOWED_TYPES:
            raise HTTPException(status_code=400, detail=f"Format non accepté: {photo.content_type}")
        data = await photo.read()
        if len(data) > MAX_FILE_SIZE:
            raise HTTPException(status_code=413, detail="Photo trop volumineuse.")
    return demo_analysis(room_name)


@app.post("/v1/calculate-move")
def calculate_move(request: MoveRequest):
    total = round(sum(room.volume_m3 for room in request.rooms), 2)

    truck_sizes = [10, 15, 20, 30, 40]
    truck = next((size for size in truck_sizes if total <= size), 40)

    # Formule provisoire : elle devra être calibrée sur de vrais déménagements.
    boxes_min = max(1, round(total * 2.1))
    boxes_max = max(boxes_min, round(total * 2.6))

    return {
        "total_volume_m3": total,
        "recommended_truck_m3": truck,
        "boxes_estimate": {
            "min": boxes_min,
            "max": boxes_max,
        },
        "rooms": [room.model_dump() for room in request.rooms],
    }
