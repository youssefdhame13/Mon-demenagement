package com.mondemenagement.app

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var roomInput: EditText
    private lateinit var photoCount: TextView
    private lateinit var resultText: TextView
    private var selectedPhotos = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        roomInput = findViewById(R.id.roomInput)
        photoCount = findViewById(R.id.photoCount)
        resultText = findViewById(R.id.resultText)

        findViewById<Button>(R.id.photoButton).setOnClickListener {
            // Première version : simulation du nombre de photos.
            // La sélection réelle de caméra/galerie sera branchée à l'étape suivante.
            selectedPhotos += 1
            photoCount.text = "$selectedPhotos photo(s) ajoutée(s)"
        }

        findViewById<Button>(R.id.analyzeButton).setOnClickListener {
            analyzeDemo()
        }
    }

    private fun analyzeDemo() {
        val room = roomInput.text.toString().ifBlank { "Pièce" }

        // Démo locale. Le backend FastAPI du dépôt possède le même contrat.
        val roomVolume = 2.47
        val truck = when {
            roomVolume <= 10 -> 10
            roomVolume <= 15 -> 15
            roomVolume <= 20 -> 20
            roomVolume <= 30 -> 30
            else -> 40
        }

        val boxesMin = (roomVolume * 2.1).roundToInt().coerceAtLeast(1)
        val boxesMax = (roomVolume * 2.6).roundToInt().coerceAtLeast(boxesMin)

        resultText.text = """
            ${room.uppercase()}

            Volume estimé : %.2f m³
            Camion conseillé : %d m³
            Cartons estimés : %d à %d

            Confiance de la démo : 91 %

            ⚠️ Cette valeur est actuellement une simulation.
            La prochaine étape consiste à connecter l'analyse réelle des photos au backend.
        """.trimIndent().format(roomVolume, truck, boxesMin, boxesMax)
    }
}
