# Architecture

```text
Android
  |
  | HTTPS
  v
FastAPI
  |
  +--> analyse des photos (provider IA à connecter)
  |
  +--> calcul volume / camion / cartons
  |
  +--> demandes de devis
```

Le fournisseur de vision doit être isolé du reste de l'application. Cela permet de changer de fournisseur sans modifier l'application Android.

Les valeurs de volume actuellement renvoyées en mode démo sont volontairement des exemples et doivent être calibrées avec des données réelles de déménagement.
