# Prochaine étape

Le dépôt est volontairement propre et fonctionnel en mode démonstration.

À faire ensuite :
1. Brancher la sélection caméra/galerie Android.
2. Envoyer les photos au endpoint `/v1/analyze-room`.
3. Remplacer `demo_analysis()` par un fournisseur de vision réel côté serveur.
4. Ajouter comptes clients/déménageurs.
5. Ajouter demandes de devis, abonnements et visibilité sponsorisée.
