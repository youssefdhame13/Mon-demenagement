# Contrat API

## GET /health

Retourne l'état du serveur.

## POST /v1/analyze-room

Multipart :

- `room_name`
- `photos[]`

Limites actuelles :
- 1 à 8 photos
- JPEG / PNG / WebP
- 10 Mo maximum par photo

La réponse contient les objets détectés, leur volume estimé et un niveau de confiance.

## POST /v1/calculate-move

JSON :

```json
{
  "rooms": [
    {"name": "Salon", "volume_m3": 12.5},
    {"name": "Chambre", "volume_m3": 7.2}
  ]
}
```

La réponse donne le volume total, une recommandation de camion et une estimation du nombre de cartons.
